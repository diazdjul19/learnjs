# simpleCRUDjs
![Gambar Web](https://1.bp.blogspot.com/-XPeggDk2604/WnbP2s3etSI/AAAAAAAAAqQ/ZcPbzxmVqMkPJijTsW4wevvUCEslH2dYACLcBGAs/s1600/121.jpg)


[Tutorial Javascript oleh petanikode.com](https://www.petanikode.com/javascript-fungsi/) 
